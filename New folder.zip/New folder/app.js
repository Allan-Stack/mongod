const express = require("express");
const app = express();
const nav = [
    {
        link:"/books" ,name:"Books"
    },
    {
        link:"/authors",name:"Authors"
    },
    {
        link:"/admin",name:"Add Book"
    },
    {
        link:"/admin1",name:"Add Author"
    },
   
    {
        linkr:"/login" ,namer:"Login"
    },
    {
        linkr:"/admin2" ,namer:"Signup"
    }
];
const booksRouter = require("./src/routes/bookRoutes")(nav)
const adminRouter = require("./src/routes/adminRoutes")(nav)
const authorRouter = require("./src/routes/authorRoutes")(nav)
 const admin1Router = require("./src/routes/admin1Routes")(nav)
const loginRouter = require("./src/routes/loginRoutes")(nav)
const signupRouter = require("./src/routes/signupRoutes")(nav)
const admin2Router = require("./src/routes/admin2Routes")(nav)
//  const admin3Router = require("./src/routes/admin3Routes")(nav)











app.use(express.urlencoded({extended:true}));
app.use(express.urlencoded({extended:true}));
app.use(express.urlencoded({extended:true}));
app.use(express.urlencoded({extended:true}));
app.use(express.urlencoded({extended:true}));
// app.use(express.urlencoded({extended:true}));

app.use(express.static('./public'));
app.set('view engine','ejs');
app.set('views','./src/views');
app.use('/books',booksRouter);
app.use('/admin1',admin1Router);
app.use('/admin',adminRouter);
app.use('/authors',authorRouter);
app.use('/login',loginRouter);
app.use('/signup',signupRouter);
app.use('/admin2',admin2Router);
//  app.use('/admin3',admin3Router);

  


app.get('/',function(req,res){
    res.render("index",{nav,
        title:"Library"
    });
});

app.listen(3500);
