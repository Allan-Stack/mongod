
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/library')
const Schema = mongoose.Schema;

const LoginSchema = new Schema({

            email: String,
            pass1 : String,
            


});
var logindata = mongoose.model('logidata',LoginSchema);
module.exports = logindata;

