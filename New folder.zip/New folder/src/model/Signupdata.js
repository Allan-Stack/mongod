
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/library')
const Schema = mongoose.Schema;

const signupSchema = new Schema({

            email: String,
            phone : String,
            pass1 : String,
            pass2 : String



});
var signupdata = mongoose.model('signupdata',signupSchema);
module.exports = signupdata;

