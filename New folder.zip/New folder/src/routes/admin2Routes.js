const express = require('express');
const admin2Router = express.Router();
const signupdata = require('../model/Signupdata');

function router (nav){
    admin2Router.get('/', function(req,res){

        res.render('signup' ,{
            nav,
            title: 'library'
        })
    })
    admin2Router.post('/add' ,function(req,res) {
        var item = {
            email: req.body.email,
            phone: req.body.phone,
             pass1: req.body.pass1,
             pass2: req.body.pass2
             


        }
        var signup = signupdata(item);
         signup.save();
     res.redirect('/login');
    
    });

    return admin2Router;

}

module.exports = router;
