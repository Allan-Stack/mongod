const express = require('express');
const admin3Router = express.Router();
const logindata = require('../model/Logindata');

function router (nav){
    admin3Router.get('/', function(req,res){

        res.render('login' ,{
            nav,
            title: 'library'
        })
    })
    admin3Router.post('/check' ,function(req,res) {
        var item = {
            email: req.body.email,
             pass1: req.body.pass1,
             
             }
            
                 logindata.find(item).then(function(data){
                     if(data!=null){
                         res.redirect('/index');
                     }
                     else {
                         res.redirect('/login')
                     }
                 })
             })
      
             
}

module.exports = router;
