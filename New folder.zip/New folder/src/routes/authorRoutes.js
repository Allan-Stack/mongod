const express = require("express");
const authorsRouter = express.Router();
const authordata = require('../model/Authordata');
function router(nav){
    // var authors = [
    //     {
    //         name: 'Stephen King',
    //         country: 'American',
    //         genre: 'Fantasy drama young adult fiction tragicomedy crime fiction',
    //         img:'stephen.jpg'
    //     },
    //     {
    //         name: 'Charles Dickens',
    //         country: 'U K',
    //         genre: 'Novel',
    //         img:'charles.jpg'
    //     },
    //     {
    //         name: 'Kamala Suraiyya',
    //         country: 'Indian',
    //         genre: 'Novel, short story',
    //         img:'kamala.jpg'
    //     }
    // ];


    authorsRouter.get("/",function(req,res){
        authordata.find()
        .then(function (authors) {
            res.render("authors",{
                nav,
                title:"Library",
                authors
            });
        })
    });
    authorsRouter.get("/:id",function(req,res){
        const id = req.params.id
        authordata.findOne({_id :id})
        .then(function(author) {
            res.render("author",{
                nav,
                title:"Library",
                author
        
            });
    
        })
    });    
    return authorsRouter;
}
module.exports = router;

