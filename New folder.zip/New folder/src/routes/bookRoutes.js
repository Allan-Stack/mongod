const express = require("express");
const booksRouter = express.Router();
const bookdata = require('../model/Bookdata');
function router(nav){
    // var books = [
    //     {
    //         title: 'Life Is What You Make It',
    //         author: 'Smita Singh',
    //         genre: ' Romance, Contemporary  ',
    //         img:'life.jpg'
    //     },
    //     {
    //         title: 'The Girl in Room 105',
    //         author: 'Chetan Bhagat',
    //         genre: 'Mysteries & Thrillers, Thrillers',
    //         img:'chetan.jpg'
    //     },
    //     {
    //         title: 'Captain Young Ghost',
    //         author: 'Ruskin Bond',
    //         genre: 'Ghost',
    //         img:'ruskin.jpg'
    //     }
    // ];
    booksRouter.get("/",function(req,res){
        bookdata.find()
        .then(function (books) {
            res.render("books",{
                nav,
                title:"Library",
                books
            });
        })
        
    });
    booksRouter.get("/:id",function(req,res){
        const id = req.params.id
        bookdata.findOne({_id :id})
        .then(function(book) {
            res.render("book",{
                nav,
                title:"Library",
                book
        
            });
            
        })
        
    });    
    return booksRouter;
}
module.exports = router;

