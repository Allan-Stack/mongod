const express = require('express');
const admin1Router = express.Router();
const authordata = require('../model/Authordata');

function router (nav){
    admin1Router.get('/', function(req,res){

        res.render('addAuthor' ,{
            nav,
            title: 'library'
        })
    })
    admin1Router.post('/add' ,function(req,res) {
        var item = {
            name: req.body.name,
            place: req.body.place,
             genre: req.body.genre,
             image: req.body.image
             


        }
        var author = authordata(item);
        author.save();
     res.redirect('/authors');
    
    });

    return admin1Router;

}

module.exports = router;
